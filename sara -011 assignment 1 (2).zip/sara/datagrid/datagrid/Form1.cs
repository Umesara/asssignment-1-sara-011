﻿using System;
using System.Data;
using System.Windows.Forms;

namespace datagrid
{
    public partial class Form1 : Form
    {
        // Define the DataTable to hold course data
        DataTable courseTable = new DataTable();

        public Form1()
        {
            InitializeComponent();
        }

        // Setup the DataTable when the form loads
        private void Form1_Load(object sender, EventArgs e)
        {
            SetupDataTable();
        }

        // Create and configure the DataTable columns
        private void SetupDataTable()
        {
            courseTable.Columns.Add("Course Code", typeof(string));
            courseTable.Columns.Add("Course Name", typeof(string));
            courseTable.Columns.Add("Obtained Marks", typeof(int));

            // Set the DataTable as the data source for the DataGridView
            dataGridView1.DataSource = courseTable;
        }

        // Add course details to the DataTable
        private void AddCourse()
        {
            // Get input values from the text boxes
            string courseCode = txtCourseCode.Text;
            string courseName = txtCourseName.Text;
            int obtainedMarks;

            // Validate the Obtained Marks input
            if (!int.TryParse(txtObtainedMarks.Text, out obtainedMarks))
            {
                MessageBox.Show("Please enter a valid number for Obtained Marks.");
                return;
            }

            // Add a new row to the DataTable with the course details
            courseTable.Rows.Add(courseCode, courseName, obtainedMarks);

            // Clear the input fields after adding the course
            txtCourseCode.Clear();
            txtCourseName.Clear();
            txtObtainedMarks.Clear();
        }

        // Trigger the AddCourse method when the button is clicked
        private void btnAddCourse_Click(object sender, EventArgs e)
        {
            AddCourse();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtCourseCode_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
